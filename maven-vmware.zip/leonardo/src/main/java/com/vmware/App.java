package com.vmware;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Employee employee = new Employee();
        employee.setName("Leonardo DaVinci");
        System.out.println( "Hello World our favorite employee is " + employee.getName() + "!");
    }
}
